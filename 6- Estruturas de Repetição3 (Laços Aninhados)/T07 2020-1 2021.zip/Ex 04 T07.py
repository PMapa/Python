C = 10
for i in range(1, C+1):
    B = C - i
    for k in range(1, B+1):
        print(f"   ", end="")
    if ( (i % 2) == 0 ):
        par = "2"; impar = "3"
    else:
        par = "P"; impar = "I"
    for j in range(B+1, (C+1)):
        if ( (j % 2) == 0 ):
            print(f"{par}  ", end="")
        else:
            print(f"{impar}  ", end="")
    print()
