for c1 in range(1, 3):
    print(f"Executando Laço externo, c1 = {c1}\n")
    for c2 in range(1, 4):
        print(f"\tExecutando Laço interno")
        print(f"\tc1 = {c1}   c2 = {c2}")
    print(f"\nVoltando ao laço externo\n")


