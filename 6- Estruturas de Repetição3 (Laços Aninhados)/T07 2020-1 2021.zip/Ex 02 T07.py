for i in range(1, 10+1):
    for j in range(1, (i+1)):
        if ( (j % 2) == 0 ):
            print(f"P  ", end="")
        else:
            print(f"#  ", end="")
    print()
