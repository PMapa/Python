C = 10
for i in range(1, C+1):
    B = C - i
    for k in range(1, B+1):
        print(f"   ", end="")
    for j in range(B+1, (C+1)):
        print(f"{j}  ", end="")
    print()
