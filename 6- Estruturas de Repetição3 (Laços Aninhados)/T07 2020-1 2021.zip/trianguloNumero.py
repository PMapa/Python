for i in range(1, 9):
    print(f"\nLinha {i}:\t", end="")
    for j in range(1, (i+1)):
        print(f"{j}   ", end="")

