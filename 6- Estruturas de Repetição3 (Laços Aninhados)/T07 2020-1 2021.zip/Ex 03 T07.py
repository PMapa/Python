for i in range(1, 10+1):
    if ( (i % 2) == 0 ):
        par = "&"; impar = "#"
    else:
        par = "A"; impar = "B"
    for j in range(1, (i+1)):
        if ( (j % 2) == 0 ):
            print(f"{par}  ", end="")
        else:
            print(f"{impar}  ", end="")
    print()
