from moduloVetor import printVetor, criaVetor, preencherVetor
# ------------------------------------------------------------------------------
# limpar a tela do shell
def cls():
    print("\n" * 60)
# ------------------------------------------------------------------------------
# PROGRAMA PRINCIPAL
cls()
print(f"                  Exercício 5")
print(f"--------------------------------------------------")
print(f"Digite todos os elementos dos vetores A e B:")
valorA = input("A: ")
A = preencherVetor(valorA, int)
valorB = input("B: ")
B = preencherVetor(valorB, int)
na = len(A); nb = len(B)
if (na != nb):
    print(f"ERRO: vetores com tamanhos diferentes !")
    print(f"na = {na}   -   nb = {nb}")
else:
    # criando o vetor C
    C = criaVetor(2 * na, float)
    # intercalando os vetores
    p = 0 # primeira posição livre de C
    for i in range(na):
        C[p] = A[i]
        C[p+1] = B[i]
        p += 2
    print(f"                  Resultados")
    print(f"--------------------------------------------------")
    print(f"Vetor com os elementos intercalados:")
    printVetor(C, float)
