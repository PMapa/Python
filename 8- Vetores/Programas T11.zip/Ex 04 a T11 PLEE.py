from moduloVetor import printVetor, criaVetor, preencherVetor
# ------------------------------------------------------------------------------
# limpar a tela do shell
def cls():
    print("\n" * 60)
# ------------------------------------------------------------------------------
# PROGRAMA PRINCIPAL
#cls()
print(f"                  Exercício 4")
print(f"--------------------------------------------------")
print(f"Digite todos os elementos dos vetores A e B:")
valorA = input("A: ")
A = preencherVetor(valorA, int)
valorB = input("B: ")
B = preencherVetor(valorB, int)
na = len(A); nb = len(B)
# criando o vetor C
C = criaVetor(na + nb, float)
# invertendo o vetor B
# criando o vetor B invertido (incialmente com zeros)
invB = criaVetor(nb, float)
p = nb - 1
for i in range(nb):
    invB[p] = B[i]
    p -= 1
# copiando o vetor A para o início de C
for i in range(na):
    C[i] = A[i]
# copiando o vetor B invertido após o final de A
for i in range(nb):
    C[na + i] = invB[i]
print(f"                  Resultados")
print(f"--------------------------------------------------")
print(f"Vetor A com B invertido:")
printVetor(C, float)
