v = [ 2, 8, 3, 72, 11, 26, 85, 33, 0, 42 ]
n = len(v)
indPar = []
for i in range(n):
    if (( v[i] % 2) == 0 ):
        indPar.append(i)
m = len(indPar); soma = 0
for i in range(m):
    k = indPar[i]
    soma = soma + v[k]
    # soma += v[ indPar[i] ]
media = soma / m

    
