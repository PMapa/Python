from moduloVetor import printVetor, preencherVetor
# ------------------------------------------------------------------------------
# limpar a tela do shell
def cls():
    print("\n" * 60)
# ------------------------------------------------------------------------------
# PROGRAMA PRINCIPAL
cls()
print(f"                  Exercício 3")
print(f"--------------------------------------------------")
valores = input(f"Digite os elementos do vetor (string): \n>>> ")
v = preencherVetor(valores, int)
n = len(v)
naoNulos = []
for i in range(n):
    if (v[i] != 0):
        naoNulos.append(v[i])
m = len(naoNulos)
print(f"                  Resultados")
print(f"--------------------------------------------------")
print(f"Vetor com elementos não nulos:")
printVetor(naoNulos, float)
print(f"\nTamanho do vetor: {m}")
