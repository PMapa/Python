from moduloVetor import printVetor
# ------------------------------------------------------------------------------
# limpar a tela do shell
def cls():
    print("\n" * 60)
# ------------------------------------------------------------------------------
# PROGRAMA PRINCIPAL
cls()
print(f"                  Exercício 2")
print(f"--------------------------------------------------")
n = int(input("Qual a dimensão do vetor ?  "))
A = float(input("Primeiro elemento do vetor ? "))
B = float(input("Segundo  elemento do vetor ? "))
vetor = []
vetor.append(A)
vetor.append(B)
for i in range(2, n):    # a partir do terceiro, índice 2
    x = vetor[i-2] + vetor[i-1]
    vetor.append(x)

print(f"                  Resultados")
print(f"--------------------------------------------------")
print(f"Vetor Gerado:")
printVetor(vetor, float)
