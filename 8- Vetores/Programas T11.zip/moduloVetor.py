# ------------------------------------------------------------------------------
'''
    A função preencherVetor é utilizada para criar um vetor de tun determinado tipo.
    Todos os elementos do vetor, separador por vírgula, são informados em uma
    única entrada pelo teclado, uma única string. A função inclui cada número válido em
    um vetor, cujos elementos são do tipo definido.
    Parâmetros: o tipo dos elementos.
    Saída: a função retorna o vetor com os elementos lidos em um único input.
'''
def preencherVetor(valores, tipo):
    vetor = [ ]
    if valores == "":
        return vetor
    else:
        valores = valores.split(',')
        for i in range(len(valores)):
            if tipo == int: 
                valor = int(valores[i].strip())
            elif tipo == float:
                valor = float(valores[i].strip())
            else:
                valor = valores[i].strip()
            vetor.append(valor)
        return vetor
# ------------------------------------------------------------------------------
'''
    A função criaVetor é utilizada para criar de um vetor de zeros com n elementos.
    Parâmetros: n, quantidade de elementos; e tipo, podendo ser int ou float.
    Saída: a função retorna o vetor criado do tipo correspondente.
'''
def criaVetor(n, tipo):
    vetor = []     # definição do vetor vazio
    for i in range(n):
        vetor.append(tipo(0))
    return vetor
# ------------------------------------------------------------------------------
'''
    A função inputVetor é utilizada para a leitura dos elementos de um vetor,
    de tamanho n, um de cada vez. A função cria um vetor.
    Parâmetros: n, quantidade de elementos; e tipo, podendo ser int ou float.
    Saída: a função retorna o vetor criado com o tipo correspondente.
    Função para a leitura dos elementos de um vetor.
    Entrada: quantidade de elementos do vetor.
    Saída: vetor (elementos do tipo float).
'''
def inputVetor(n, tipo):
    vetor = []
    for i in range(n):
        mensagem = f"Elemento [{i}]:  "
        elemento = input(mensagem);
        vetor.append(tipo(elemento))
    return vetor
# ------------------------------------------------------------------------------
'''
    A função printVetor imprime os elementos de um vetor.
    Parâmetros: variável do vetor e tipo dos elementos do vetor.
    Saída: nenhum valor (somente a impressão dos elementos na tela).
'''
def printVetor(vetor, tipo):
    n = len(vetor)
    print("[  ", end='')
    for i in range(n):
        if (tipo == float):
            print(f"{vetor[i]:4.1f}  ", end='')
        else:
            print(f"{vetor[i]:3d}  ", end='')
    print("]", end='')
# ------------------------------------------------------------------------------
'''
    A função criaVetor é utilizada para a criação de um vetor, onde o primeiro
    elemento é "inicio", e os próximos elementos possuem o incremento do "passo"
    de forma acumulada. Todos os valores são menores ou iguais ao "fim".
    Entrada: valores inteiros para "inicio", "passo" e "fim".
    Saída: um vetor de elementos float.
'''
def criaVetorAB(inicio, passo, fim, tipo):
    vetor = []
    i = inicio
    while i <= fim:
        vetor.append(tipo(i))
        i = i + passo
    return vetor
# ------------------------------------------------------------------------------