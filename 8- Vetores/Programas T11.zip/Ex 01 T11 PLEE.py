from moduloVetor import inputVetor, printVetor
# ------------------------------------------------------------------------------
# limpar a tela do shell
def cls():
    print("\n" * 60)
# ------------------------------------------------------------------------------
# PROGRAMA PRINCIPAL
cls()
print(f"        Exercício 1 - Vetores de Índices")
print(f"--------------------------------------------------")
n = int(input("Qual a dimensão do vetor ?  "))
print(f"Leitura dos elementos do vetor...")
v = inputVetor(n, int)
indPar = []; indImpar = []; par = 0; impar = 0
mediaPar = 0; mediaImpar = 0
for i in range(n):
    if ( (v[i] % 2) == 0 ):
        indPar.append(i)
        par +=1
    else:
        indImpar.append(i)
        impar +=1
for i in range(par):
    mediaPar += v[ indPar[i] ]
mediaPar /= par
for i in range(impar):
    mediaImpar += v[ indImpar[i] ]
mediaImpar /= impar
print(f"                  Resultados")
print(f"--------------------------------------------------")
print(f"Vetor Original:")
printVetor(v, int)
print(f"\n\nÍndices dos Elementos Pares")
printVetor(indPar, int)
print(f"\nMédia Aritmética dos Pares: {mediaPar:8.4f}")
print(f"\nÍndices dos Elementos Ímpares")
printVetor(indImpar, int)
print(f"\nMédia Aritmética dos Ímpares: {mediaImpar:8.4f}")
