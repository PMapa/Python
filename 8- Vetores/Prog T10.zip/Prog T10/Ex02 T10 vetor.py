'''
      Escreva um programa que preencha dois vetores de 4
elementos através de entradas pelo teclado. Após a definição
dos dois vetores, construa um terceiro vetor onde cada
elemento é o dobro da soma entre os elementos correspondentes
dos vetores lidos. Imprima o vetor calculado.

'''
n = 4
print(f"Leitura dos elementos dos vetores:")
VA = []
VB = []
# criando o vetor VC com 4 elementos nulos
VC = []
for i in range(n):
    VC.append(int(0))
for i in range(n):
    elemento = input(f"Elemento VA[{i}]: ")
    VA.append(float(elemento))
    elemento = input(f"Elemento VB[{i}]: ")
    VB.append(float(elemento))
    VC[i] = 2 * (VA[i] + VB[i])
print(f"Vetor A")
print("[  ", end='')
for i in range(n):
    print(f"{VA[i]:4.1f}  ", end='')
print("]")
print(f"Vetor B")
print("[  ", end='')
for i in range(n):
    print(f"{VB[i]:4.1f}  ", end='')
print("]")
print(f"Vetor C")
print("[  ", end='')
for i in range(n):
    print(f"{VC[i]:4.1f}  ", end='')
print("]")
