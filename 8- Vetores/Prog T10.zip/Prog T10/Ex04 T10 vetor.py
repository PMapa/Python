'''
    Escreva um programa que preencha um vetor com entradas do usuário.
Considere que o usuário definirá apenas valores numéricos positivos (ou nulos),
e que, ao desejar encerrar a definição dos elementos ele digite um valor negativo.
    Após a entrada de todos os elementos do vetor, calcule e imprima o seu
somatório, sem a utilização de funções de qualquer biblioteca.

'''
from moduloVetor import *
n = 0    # elementos do vetor
A = []
print(f"Leitura dos elementos do vetor A:")
x = float(input(f"Digite o elemento {n}: "))
while (x >= 0):
    A.append(x)
    n += 1
    x = float(input(f"Digite o elemento {n}: "))
# impressões
print(f"Vetor A")
printVetor(A, float)
# Cálculo do somatório dos elementos de A
media = 0
tam = n - 1
for i in range(tam):
    media += A[i]
media /= tam
print(f"\nMédia dos elementos de A: {media:8.3f}")
