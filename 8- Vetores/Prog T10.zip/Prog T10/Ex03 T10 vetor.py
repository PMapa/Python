'''
    Faça um programa que preencha dois vetores de 4 elementos através de entradas do usuário.
    Após a definição dos dois vetores, construa um terceiro vetor (8 elementos) onde os elementos
de índice par recebem os valores do primeiro vetor e os elementos de índice ímpar recebem os valores
do segundo vetor. Imprima o vetor calculado.

'''
from moduloVetor import *
n = 4
print(f"Leitura do vetor A:")
A = inputVetor(n, float)
print(f"Leitura do vetor B:")
B = inputVetor(n, float)
C = criaVetor(2*n, float)
# gerando os elementos de C
j = 0; k = 0
for i in range(2*n):
    if ((i % 2) == 0):
        C[i] = A[j]
        j += 1
    else:
        C[i] = B[k]
        k += 1

# impressões
print(f"Vetor A")
printVetor(A, float)
print(f"\nVetor B")
printVetor(B, float)
print(f"\nVetor C")
printVetor(C, float)
