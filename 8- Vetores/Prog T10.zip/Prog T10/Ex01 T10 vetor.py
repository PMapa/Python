'''
Escreva um programa que preencha um vetor de n elementos
(float), através de entradas pelo teclado.
Após a definição dos elementos do vetor, calcule a média
dos valores do vetor.
'''
n = int(input("Dimensão do vetor: "))
print(f"Leitura dos elementos do vetor:")
vetor = []
for i in range(n):
    mensagem = f"Elemento [{i}]:  "
    elemento = input(mensagem);
    vetor.append(float(elemento))
media = 0
for i in range(n):
    media += vetor[i]
media /= n
print(f"Média aritmética dos elementos: {media:6.2f}")
# poderíamos usar somente um for ?
