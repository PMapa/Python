comp    = float(input("Comprimento de corte dos tubos: "))
margem  = float(input("Margem de erro aceitável: "))
demanda = int(input("Quantidade de tubos demandada: "))
aceito = 0
rejeitado = 0
while (aceito < demanda):
    tubo = float(input("Comprimento do tubo cortado: "))
    erro = abs(tubo - comp)
    if (erro <= margem):
        aceito += 1
    else:
        rejeitado += 1
        print(f"Acima da margem de erro, tubo rejeitado.")
    # próximo tubo
print(f"Fim da produção, demanda atendida.")
print(f"Total de tubos cortados: {aceito + rejeitado}")
print(f"Total de tubos rejeitados: {rejeitado}.")