n = int(input("Digite um número: "))
while (n > 0):
    d = 1
    soma = 0
    while (d < n):
        if ( (n % d) == 0 ):
            soma = soma + d
        d = d + 1
    if (n == soma):
        print(f"{n} == {soma}: número é perfeito")
    else:
        print(f"{n} != {soma}: número é não perfeito")
    n = int(input("Digite um número: "))
