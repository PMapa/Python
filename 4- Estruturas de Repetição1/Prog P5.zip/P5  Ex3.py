T = float(input("Capital total para empréstimo: "))
C = float(input("Capital emprestado: "))
while (C <= T):
    m =int(input("Quantidade de meses para quitação: "))
    if (C <= 10000):
        t = 0.1
    else:
        t = 0.07
    J = C * t * m
    print(f"Taxa de juros aplicada: {(t*100):.0f} %")
    print(f"Juros devido: {J:.2f}")
    divida = C + J
    print(f"Valor total: {divida:.2f}")
    T = T - C
    C = float(input("Capital emprestado: "))
print(f"Emprestimo negado, capital total é de R$ {T:.2f}")