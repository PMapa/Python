n = int(input("Informe o número que deseja calcular o Fatorial: "))
while (n < 0):
    n = int(input(f"Número inválido, defina outro: "))
# n é um número natural n >= 0
nro = n
fat = 1
while (nro != 0):
    fat = fat * nro
    nro -= 1
print(f"O Fatorial de {n} é: {fat}")
